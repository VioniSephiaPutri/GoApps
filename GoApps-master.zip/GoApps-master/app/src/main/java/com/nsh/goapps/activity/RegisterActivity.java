package com.nsh.goapps.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.nsh.goapps.R;

public class RegisterActivity extends AppCompatActivity {
    protected void onCreate (Bundle saveInstanceState)
    {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_registeruser);

    }
}
